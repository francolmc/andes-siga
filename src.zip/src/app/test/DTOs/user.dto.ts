export default class UserDTO {
    id: number;
    firstName: string;
    lastName: string;
    age: number;
}