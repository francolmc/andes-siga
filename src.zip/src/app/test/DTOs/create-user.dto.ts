export default class CreateUsersDTO {
    firstName: string;
    lastName: string;
    age: number;
}