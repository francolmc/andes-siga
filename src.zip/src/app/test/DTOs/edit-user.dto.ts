export default class EditUsersDTO {
    firstName: string;
    lastName: string;
    age: number;
}