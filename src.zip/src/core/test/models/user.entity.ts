export class UserEntity {
    id: number;
    firstName: string;
    lastName: string;
    age: number;
}